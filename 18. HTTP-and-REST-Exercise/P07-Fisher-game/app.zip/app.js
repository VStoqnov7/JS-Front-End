function solve() {
  let BASE_URL = "http://localhost:3030";
  let btnHome = document.querySelector("#home");
  let btnLogout = document.querySelector("#logout");
  let btnLogin = document.querySelector("#login");
  let btnRegister = document.querySelector("#register");
  let btnLoad = document.querySelector("#home-view > aside > button");
  let pWelcome = document.querySelector("body > header > nav > p");
  let display = document.querySelector("body > main");
  let register = document.querySelector("#views");
  let registerSection = document.querySelector("#register-view");
  let loginSection = document.querySelector("#login-view");
  let chaches = document.querySelector("#home-view");
  let fields = document.querySelector("#main");
  let aside = document.querySelector("#home-view > aside");
  let accessToken = null;
  let currentUser = null;
  btnLogout.style.display = "none";
  register.style.display = "none";

  fields.style.display = "none";
  removeclassListBtn();

  document.addEventListener("click", function (event) {
    if (event.target === btnHome) {
      home();
    } else if (event.target === btnLogin) {
      login();
    } else if (event.target === btnRegister) {
      registers();
    } else if (event.target === btnLogout) {
      logout();
    }
  });

  function home() {
    removeclassListBtn();
    btnHome.classList.add("active");
    display.innerHTML = "";
    display.appendChild(chaches);
  }

  function login() {
    removeclassListBtn();
    btnLogin.classList.add("active");
    display.innerHTML = "";
    display.appendChild(loginSection);

    let emailLogin = document.querySelector(
      "#login > label:nth-child(1) > input[type=text]"
    );
    let passwordLogin = document.querySelector(
      "#login > label:nth-child(2) > input[type=password]"
    );

    let buttonLogin = document.querySelector("#login > button");

    buttonLogin.addEventListener("click", log);

    async function log(event) {
      event.preventDefault();

      let urlToCheck = "http://localhost:3030/users/login";

      try {
        let response = await fetch(urlToCheck, {
          method: "POST",
          body: JSON.stringify({
            email: emailLogin.value,
            password: passwordLogin.value,
          }),
        });

        if (!response.ok) {
          throw new Error("Login failed.");
        }

        let data = await response.json();

        if (data.accessToken) {
          accessToken = data.accessToken;
          currentUser = emailLogin.value;

          //   btnLoad.addEventListener("click", loadCatches);

          //   fields.style.display = "inline";
          //   loadCatches();

          btnLogin.style.display = "none";
          btnRegister.style.display = "none";
          btnLogout.style.display = "block";
          pWelcome.textContent = `Welcome, ${emailLogin.value}`;
          home();

          let disabledButtonAdd = document.querySelector(
            "#addForm > fieldset > button"
          );
          disabledButtonAdd.disabled = false;
        } else {
          throw new Error("Login failed.");
        }
      } catch (error) {
        console.error("Login failed:", error);
        let message = document.querySelector("#login > p");
        message.textContent =
          "Error: Login failed. Please check your credentials and try again.";
      }
    }
  }

  async function registers() {
    removeclassListBtn();
    btnRegister.classList.add("active");
    display.innerHTML = "";
    display.appendChild(registerSection);

    let email = document.querySelector(
      "#register > label:nth-child(1) > input[type=text]"
    );
    let password = document.querySelector(
      "#register > label:nth-child(2) > input[type=password]"
    );

    let repeat = document.querySelector(
      "#register > label:nth-child(3) > input[type=password]"
    );

    let btnFetchRegister = document.querySelector("#register > button");

    btnFetchRegister.addEventListener("click", reg);

    async function reg(event) {
      event.preventDefault();
      let message = document.querySelector("#register > p");
      message.textContent = "";

      if (email.value.trim() === "" || password.value.trim() === "") {
        message.textContent = "Error: Email and password are required.";
      } else if (password.value !== repeat.value) {
        message.textContent = "Error: Passwords do not match.";
      } else {
        let urlRegister = "http://localhost:3030/users/register/";

        let object = {
          method: "POST",
          body: JSON.stringify({
            email: email.value,
            password: password.value,
          }),
        };

        let response = await fetch(urlRegister, object);

        email.value = "";
        password.value = "";
        repeat.value = "";
        home();
      }
    }
  }

  async function logout() {
    let urlLogout = "http://localhost:3030/users/logout/";
    try {
      let response = await fetch(urlLogout, {
        method: "GET",
        headers: {
          "X-Authorization": accessToken,
        },
      });

      if (!response.ok) {
        throw new Error("Logout failed.");
      }

      accessToken = null;
      currentUser = null;
      home();
      pWelcome.textContent = `Welcome, guest`;
      fields.style.display = "none";
      let buttonToDisable = document.querySelector(
        "#addForm > fieldset > button"
      );
      buttonToDisable.disabled = true;
      btnLogout.style.display = "none";
      btnLogin.style.display = "inline";
      btnRegister.style.display = "inline";
    } catch (error) {
      console.error(error);
    }
  }

  async function loadCatches() {
    if (accessToken === null) {
      return;
    }
    let fields = document.querySelector("#main");
    fields.style.display = "inline";
    let catches = document.querySelector("#catches");
    catches.innerHTML = "";
    load();

    async function load() {
      if (currentUser !== null) {
        let urlCatch = "http://localhost:3030/data/catches/";
        let urlCatchFetch = await fetch(urlCatch);
        let urlCatchArray = await urlCatchFetch.json(); // Parse the JSON response

        urlCatchArray.forEach((element) => {
          let catchElement = document.createElement("div");
          catchElement.classList.add("catch");
          catchElement.setAttribute("data-id", element._id);

          catchElement.innerHTML = `
                    <label>Angler</label>
                    <input type="text" class="angler" value="${element.angler}" />
                    <label>Weight</label>
                    <input type="number" class="weight" value="${element.weight}" />
                    <label>Species</label>
                    <input type="text" class="species" value="${element.species}" />
                    <label>Location</label>
                    <input type="text" class="location" value="${element.location}" />
                    <label>Bait</label>
                    <input type="text" class="bait" value="${element.bait}" />
                    <label>Capture Time</label>
                    <input type="number" class="captureTime" value="${element.captureTime}" />
                    <button class="update">Update</button>
                    <button class="delete">Delete</button>
                `;
          if (accessToken === urlCatchFetch.accessToken) {
            let btnUpdate = catchElement.querySelector("button.update");
            btnUpdate.disabled = "true";
            let btnDelete = catchElement.querySelector("button.delete");
            btnDelete.disabled = true;
          } else {
            let btnUpdate = catchElement.querySelector("button.update");
            btnUpdate.addEventListener("click", () => update(element._id));

            let btnDelete = catchElement.querySelector("button.delete");
            btnDelete.addEventListener("click", () => deleteCatch(element._id));
            catches.appendChild(catchElement);
          }
        });
      }
    }

    async function update(catchId) {
      // Implement the update functionality using a PUT request
      let angler = document.querySelector(
        `.catch[data-id="${catchId}"] .angler`
      ).value;
      let weight = document.querySelector(
        `.catch[data-id="${catchId}"] .weight`
      ).value;
      let species = document.querySelector(
        `.catch[data-id="${catchId}"] .species`
      ).value;
      let location = document.querySelector(
        `.catch[data-id="${catchId}"] .location`
      ).value;
      let bait = document.querySelector(
        `.catch[data-id="${catchId}"] .bait`
      ).value;
      let captureTime = document.querySelector(
        `.catch[data-id="${catchId}"] .captureTime`
      ).value;

      let urlUpdate = `http://localhost:3030/data/catches/${catchId}`;

      try {
        if (accessToken) {
          let response = await fetch(urlUpdate, {
            method: "PUT",
            body: JSON.stringify({
              angler,
              weight,
              species,
              location,
              bait,
              captureTime,
            }),
          });

          if (!response.ok) {
            throw new Error("Update failed.");
          }
        }
        // Update succeeded, you may want to refresh the catches list or show a success message
        console.log("Update successful");
      } catch (error) {
        console.error(error);
      }
    }

    async function deleteCatch(catchId) {
      // Implement the delete functionality using a DELETE request
      let urlDelete = `http://localhost:3030/data/catches/${catchId}`;

      try {
        let response = await fetch(urlDelete, {
          method: "DELETE",
          headers: {
            "X-Authorization": accessToken, // Add authorization header
          },
        });

        if (!response.ok) {
          throw new Error("Delete failed.");
        }

        // Delete succeeded, you may want to refresh the catches list or show a success message
        console.log("Delete successful");
      } catch (error) {
        console.error(error);
      }
    }
  }

  function removeclassListBtn() {
    let navButtons = document.querySelectorAll("a");
    navButtons.forEach((otherButton) => {
      otherButton.classList.remove("active");
    });
  }
}

solve();
