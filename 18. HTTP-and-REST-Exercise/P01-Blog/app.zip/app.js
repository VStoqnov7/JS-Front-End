function attachEvents() {
  let URL_POSTS = "http://localhost:3030/jsonstore/blog/posts/";

  let btnLoadPosts = document.querySelector("#btnLoadPosts");

  let options = document.querySelector("#posts");

  btnLoadPosts.addEventListener("click", loadPosts);

  const postBodyMap = new Map();

  async function loadPosts() {
    try {
      let response = await fetch(URL_POSTS);
      let postsJson = await response.json();
      let postsArray = Object.values(postsJson);

      postsArray.forEach((element) => {
        let body = element.body;
        let id = element.id;
        let title = element.title;
        let option = document.createElement("option");
        option.value = id;
        option.textContent = title.toUpperCase();
        options.appendChild(option);
        postBodyMap.set(id, body);
      });
    } catch (error) {
      console.error(error);
    }

    let butViewPosts = document.querySelector("#btnViewPost");
    let URL_COMMENTS = "http://localhost:3030/jsonstore/blog/comments/";

    butViewPosts.addEventListener("click", addCo.ments);

    async function addComments() {
      try {
        let response = await fetch(URL_COMMENTS);
        let commentsJson = await response.json();
        let commentsArray = Object.values(commentsJson);

        let selectElement = document.querySelector("#posts");
        let selectedOption = selectElement.selectedOptions[0];

        let h1 = document.querySelector("#post-title");
        let ul = document.querySelector("#post-comments");
        let p = document.querySelector("#post-body");

        commentsArray.forEach((element) => {
          if (element.id === selectedOption.value) {
            h1.textContent = selectedOption.textContent;

            p.textContent = postBodyMap.get(selectedOption.value);
            let li = document.createElement("li");
            li.textContent = element.text;
            ul.appendChild(li);
          }
        });
      } catch (error) {
        console.error(error);
      }
    }
  }
}
attachEvents();
